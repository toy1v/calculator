# (Btc_price_forecast/setup.py)
基于Paddle构建简单神经网络比特币价格预测
